function ls --wraps='eza -lh' --description 'alias ls=eza -lh'
  eza -lh $argv
        
end
